#!/usr/bin/env python3
"""
Standalone execution script for 1 Real Marshmallow W Attempt.
Compatible with Google Colab (/content) and Kaggle (/kaggle/working).
"""
import os
import sys
import json
import time

# Auto-detect base directory
if os.path.exists("/kaggle/working"):
    BASE_DIR = "/kaggle/working"
elif os.path.exists("/content"):
    BASE_DIR = "/content"
else:
    BASE_DIR = os.getcwd()

if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)

import torch
print("=" * 80)
print(f"HARDWARE DIAGNOSTIC - Workspace: {BASE_DIR}")
print("=" * 80)
print(f"PyTorch Version  : {torch.__version__}")
print(f"CUDA Available   : {torch.cuda.is_available()}")
if torch.cuda.is_available():
    print(f"Device Name      : {torch.cuda.get_device_name(0)}")
    print(f"Device VRAM      : {torch.cuda.get_device_properties(0).total_memory / (1024**3):.2f} GB")
else:
    print("FATAL: No CUDA GPU detected! In Kaggle, set Accelerator to 'GPU T4 x2' or 'GPU P100'.")
    sys.exit(1)

# Step 1: Ensure marshmallow task repository is prepared
from gemma_paper.dataset_prep import prepare_repository_at_base_commit

TASK_ID = "marshmallow-code__marshmallow-1343"
REPO_NAME = "marshmallow-code/marshmallow"
BASE_COMMIT = "2be2d83a1a9a6d3d9b85804f3ab545cecc409bb0"
TASK_REPO_DIR = os.path.join(BASE_DIR, "task_repos", TASK_ID.replace("/", "__"))

print("\n" + "=" * 80)
print("PREPARING TASK REPOSITORY")
print("=" * 80)
prepare_repository_at_base_commit(REPO_NAME, BASE_COMMIT, TASK_REPO_DIR)

# Step 2: Load Model and Processor in Explicit 8-bit mode
from gemma_paper.model_loader import load_gemma4_and_processor, verify_quantization_and_placement

MODEL_ID = "google/gemma-4-E4B-it"
MODEL_REVISION = "4ecc2ba63bcac23ba4a767fc87025b1450f84c9c"

print("\n" + "=" * 80)
print(f"LOADING MODEL: {MODEL_ID} (rev={MODEL_REVISION}) [8-bit BitsAndBytes]")
print("=" * 80)
model, processor, unquantized_dtype = load_gemma4_and_processor(
    model_id=MODEL_ID,
    revision=MODEL_REVISION,
    use_4bit=False
)

quant_report = verify_quantization_and_placement(model)

# Step 3: Load Evidence Packet for Marshmallow W
from gemma_paper.repair_runner import run_single_attempt

CONDITION = "W"
OUTPUT_DIR = os.path.join(BASE_DIR, "inference_output")
PACKET_PATH = os.path.join(BASE_DIR, "evidence_packets", f"{TASK_ID}__{CONDITION}.json")

if not os.path.exists(PACKET_PATH):
    raise FileNotFoundError(f"Evidence packet not found at {PACKET_PATH}! Please extract the archive into {BASE_DIR}.")

with open(PACKET_PATH, "r", encoding="utf-8") as f:
    evidence_packet = json.load(f)

print("\n" + "=" * 80)
print("EXECUTING REAL MARSHMALLOW W INFERENCE ATTEMPT")
print("=" * 80)
record = run_single_attempt(
    model=model,
    processor=processor,
    task_id=TASK_ID,
    condition=CONDITION,
    evidence_packet=evidence_packet,
    output_dir=OUTPUT_DIR,
    repos_base_dir=os.path.join(BASE_DIR, "task_repos"),
    attempt=1
)

print("\n" + "=" * 80)
print("EXECUTION RESULTS (COPY AND PASTE INTO CHAT)")
print("=" * 80)
print(f"Checkpoint Key      : {record['checkpoint_key']}")
print(f"Execution Mode      : {record['execution_mode']}")
print(f"Input Tensor Tokens : {record['token_counts']['input_tokens']}")
print(f"Generated Tokens    : {record['token_counts']['generated_tokens']}")
print(f"Elapsed Time        : {record['elapsed_seconds']}s")
print(f"Peak VRAM Usage     : {record['memory_measurements']['after'].get('peak_mb', 'N/A')} MB")
print(f"Generation Status   : {record['generation_status']} (finish: {record['finish_reason']})")
print(f"Conversion Status   : {record['conversion_status']}")
print(f"Patch Applicability : {record['patch_applicability']}")
print(f"Test Resolution     : {record['test_resolution']}")
print(f"Prediction File     : {OUTPUT_DIR}/predictions/{record['checkpoint_key']}.json")
print("\n--- Extracted Model Patch ---")
print(record["model_patch"] if record["model_patch"] else "[No unified diff extracted]")
print("=" * 80)
